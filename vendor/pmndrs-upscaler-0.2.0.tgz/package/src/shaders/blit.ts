import { WGSL_CONSTANTS, WGSL_TONEMAP } from './common';
import { assembleShader } from './wgsl';

/**
 * Output/blit pass.
 *
 * Samples the input (bilinear — which doubles as the naive-upscale
 * comparison mode in the bench) and writes in the caller's color domain.
 * Input interpretation by flag:
 * - `FLAG_INPUT_REINHARD` — temporal history in invertible-tonemap space
 * - otherwise — caller-domain color, passed through unchanged
 *
 * Bindings:
 * - 1: input color (filterable float)
 * - 2: linear clamp sampler
 * - 3: exposure, 1×1 (rgba16float; r = pre-exposure to undo on the temporal path)
 * - 4: output storage (rgba16float, display size)
 * - 5: alpha source — RGBA build only (see below)
 *
 * Alpha is carried by a separate binding because the temporal path's input is
 * the accumulate history, whose alpha channel is the accumulation age — the
 * resolved alpha lives in the locks buffer's spare `.a` instead. On the
 * bilinear and spatial paths binding 5 is simply the input texture again, so
 * one `textureSampleLevel` covers all three without a branch.
 *
 * `alpha: false` builds the opaque pipeline instead: no binding 5, no fetch, a
 * literal 1.0 in the store. The choice is made once at pipeline creation, so
 * neither build pays a runtime branch or carries the other's registers.
 */
function createBlitShader(alpha: boolean): string {
    return assembleShader(
        WGSL_CONSTANTS,
        WGSL_TONEMAP,
        /* wgsl */ `
@group(0) @binding(1) var inputColor : texture_2d<f32>;
@group(0) @binding(2) var linearSampler : sampler;
@group(0) @binding(3) var exposureTex : texture_2d<f32>;
@group(0) @binding(4) var outputColor : texture_storage_2d<rgba16float, write>;${
            alpha ? '\n@group(0) @binding(5) var alphaSource : texture_2d<f32>;' : ''
        }

@compute @workgroup_size(8, 8)
fn main(@builtin(global_invocation_id) gid : vec3u) {
    if (any(vec2f(gid.xy) >= C.displaySize)) { return; }

    let uv = (vec2f(gid.xy) + 0.5) * C.displaySizeInv;
    var c = textureSampleLevel(inputColor, linearSampler, uv, 0.0).rgb;

    if (hasFlag(FLAG_INPUT_REINHARD)) {
        // Undo the pre-exposure the accumulate pass baked in before tonemapping.
        let exposure = max(textureLoad(exposureTex, vec2i(0), 0).r, 1.0e-4);
        c = tonemapInvert(c) / exposure;
    }

    ${
        alpha
            ? 'let a = textureSampleLevel(alphaSource, linearSampler, uv, 0.0).a;\n    textureStore(outputColor, gid.xy, vec4f(c, a));'
            : 'textureStore(outputColor, gid.xy, vec4f(c, 1.0));'
    }
}
`,
    );
}

/** Production build: the caller's alpha is preserved. */
export const BLIT_SHADER = createBlitShader(true);

/**
 * Opaque build (`alpha: false`). Byte-identical to the pre-alpha shader — the
 * `blit` fingerprint test pins that, so the opt-out is provably a no-op rather
 * than a second code path that drifts.
 */
export const BLIT_OPAQUE_SHADER = createBlitShader(false);
